# GO Stag

[![Build Status](https://travis-ci.com/hirsch88/go-stag.svg?branch=master)](https://travis-ci.com/hirsch88/go-stag)
